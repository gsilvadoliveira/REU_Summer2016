require_relative '../test_helper'

class TestShellSecretary < Minitest::Test

  def test_test

  end

end
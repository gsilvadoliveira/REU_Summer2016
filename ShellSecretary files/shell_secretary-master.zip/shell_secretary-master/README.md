shell_secretary
3/4 capstone  project written in Ruby.

## Project Vision

This will be a small command-line program that keeps track of user tasks, events, or reminders logged onto a calendar.
Users will be able to add/edit/delete data as well as query the app for weekly/monthly/yearly/daily formatted upcoming items
logged into the program.

## Features
### Viewing the data
In order to stay organized I want to see the  upcoming obligations I have set for myself.

### Viewing the data in organized sets
In order to check what tasks, events, or reminders I have upcoming I want view them grouped by the set
year, month, week, or day.
#
### Adding a new task/event/reminder
In order to have usable data I want to be able to add items to my calendar.

Usage Example:

      > ./shell_secretary manage
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit
      > 1
      Please enter the Date fallowed by note, [mm/dd/yyyy] [Task/event/reminder].
      >09/09/2015 It's your birthday!
      "09/09/2015 It's your birthday!" logged into your calendar.
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit

Acceptance Criteria:

   * New item logged to data base

### Editing existing tasks/events/reminders

In order to fix typos and/or remove items I want to edit existing data.

Usage Example:

      > ./shell_secretary manage
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit
      > 2
      1. 06/06/2015  Show at the Raman @ 7pm
      2. 08/22/2015  Hair appointment at Parlor & Juke @ 4:15pm
      3. 09/09/2015  Happy Birthday!
      > 2
      08/22/2015  Hair appointment at Parlor & Juke @ 4:15pm
      What would you like to do?
      1. Edit
      2. Delete
      3. Exit
      > 1
      Please reenter information for
      08/22/2015  Hair appointment at Parlor & Juke @ 4:15pm
      [mm/dd/yyyy] [engagement]
      >"08/22/2015  Hair appointment at Parlor & Juke @ 5:15pm"
      changes saved to calendar
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit

Acceptance Criteria

   * Existing item in data base edited

### Viewing all existing logged inputs

In order to evaluate and/or manage the existing data
I want to view all the existing scenarios

 Usage Example:

      > ./shell_secretary manage
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit
      > 2
      1. 06/06/2015  Show at the Ryman @ 7pm
      2. 08/22/2015  Hair appointment at Parlor & Juke @ 4:15pm
      3. 09/09/2015  Happy Birthday!

Acceptance Criteria:

  * All engagements are printed out
  * Each engagement is given a number, which does not correspond to its database id

### Deleting a scenario

In order to remove duplicates and/or tasks that are no longer relevant
I want to delete an existing scenario

Usage Example:

      > ./shell_secretary manage
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit
      > 2
      1. 06/06/2015  Show at the Raman @ 7pm
      2. 08/22/2015  Hair appointment at Parlor & Juke @ 4:15pm
      3. 09/09/2015  Happy Birthday!
      > 1
      06/06/2015  Show at the Ryman @ 7pm
      What would you like to do?
      1. Edit
      2. Delete
      3. Exit
      >2
      "06/06/2015  Show at the Ryman @ 7pm" has been deleted
      1. Add an event/task/reminder
      2. List all upcoming events/tasks/reminders
      3. List all passed events/tasks/reminders
      4. Exit

Acceptance Criteria:

  * Program prints out confirmation that the scenario was deleted
  * The deleted scenario is removed from the database
  * All references to the deleted scenario are removed from the database
  * After the deletion, the user is taken back to the main manage menu

